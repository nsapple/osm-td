@tool
extends Node2D

@export var address: String = ""
@export var radius_miles: float = 3.0
@export var tile_zoom: int = 16
@export var pixels_per_meter: float = 0.1
@export var debug_enabled: bool = true
@export var debug_font_size: int = 14

signal map_ready
signal map_error(message: String)

var _center_lat: float = 0.0
var _center_lon: float = 0.0
var _radius_meters: float = 4828.0
var _roads_node: Node2D = null
var _ground_node: Node2D = null
var _debug_node: Node2D = null
var _http_nominatim: HTTPRequest = null
var _http_overpass: HTTPRequest = null
var _http_tiles: HTTPRequest = null
var _tile_queue: Array = []
var _tile_images: Dictionary = {}
var _tile_bounds: Dictionary = {}
var _road_data: Array = []
var _fetch_start_time: int = 0
var _geocode_time: int = 0
var _roads_time: int = 0
var _tiles_time: int = 0
var _total_nodes: int = 0
var _total_ways: int = 0
var _tiles_loaded: int = 0
var _tiles_failed: int = 0
var _tiles_total: int = 0
var debug_log: Array = []


func _ready() -> void:
	_http_nominatim = HTTPRequest.new()
	_http_nominatim.name = "HTTPNominatim"
	add_child(_http_nominatim)
	_http_nominatim.request_completed.connect(_on_nominatim_response)

	_http_overpass = HTTPRequest.new()
	_http_overpass.name = "HTTPOverpass"
	add_child(_http_overpass)
	_http_overpass.request_completed.connect(_on_overpass_response)

	_http_tiles = HTTPRequest.new()
	_http_tiles.name = "HTTPTiles"
	add_child(_http_tiles)
	_http_tiles.request_completed.connect(_on_tile_response)


@export_tool_button("Fetch Map")
var fetch_button: Callable = func() -> void: fetch_map(address)


func fetch_map(addr: String) -> void:
	if addr.is_empty():
		map_error.emit("Address is empty.")
		_dlog("ERROR: Address is empty.")
		return

	address = addr
	_radius_meters = radius_miles * 1609.34
	_fetch_start_time = Time.get_ticks_msec()
	debug_log.clear()
	_tiles_loaded = 0
	_tiles_failed = 0
	_total_nodes = 0
	_total_ways = 0
	_clear_previous()

	_dlog("Starting fetch for: " + addr)
	_dlog("Radius: " + str(radius_miles) + " mi (" + str(int(_radius_meters)) + " m)")

	var encoded: String = addr.uri_encode()
	var url: String = "https://nominatim.openstreetmap.org/search?q=" + encoded + "&format=json&limit=1"
	var headers: PackedStringArray = PackedStringArray(["User-Agent: GodotMapFetcher/1.0"])
	var err: int = _http_nominatim.request(url, headers)
	if err != OK:
		map_error.emit("Failed to send geocoding request")
		_dlog("ERROR: Nominatim request failed")


func _clear_previous() -> void:
	if _roads_node:
		_roads_node.queue_free()
		_roads_node = null
	if _ground_node:
		_ground_node.queue_free()
		_ground_node = null
	if _debug_node:
		_debug_node.queue_free()
		_debug_node = null
	_road_data.clear()
	_tile_queue.clear()
	_tile_images.clear()
	_tile_bounds.clear()


func _dlog(msg: String) -> void:
	var timestamp: int = Time.get_ticks_msec() - _fetch_start_time
	var entry: String = "[" + str(timestamp) + "ms] " + msg
	debug_log.append(entry)
	print("MapFetcher: " + entry)


func _on_nominatim_response(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_geocode_time = Time.get_ticks_msec()

	if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
		map_error.emit("Geocoding failed (HTTP " + str(response_code) + ").")
		_dlog("ERROR: Geocoding failed HTTP " + str(response_code))
		return

	var json: Variant = JSON.parse_string(body.get_string_from_utf8())
	if json == null or not json is Array or (json as Array).size() == 0:
		map_error.emit("No results found for address: " + address)
		_dlog("ERROR: No geocoding results")
		return

	var arr: Array = json as Array
	var first: Dictionary = arr[0] as Dictionary
	_center_lat = float(first["lat"])
	_center_lon = float(first["lon"])
	var display_name: String = str(first.get("display_name", ""))
	_dlog("Geocoded: lat=" + str(_center_lat) + " lon=" + str(_center_lon))
	_dlog("Full name: " + display_name)
	_fetch_roads()


func _fetch_roads() -> void:
	_dlog("Querying Overpass for roads...")

	var query: String = '[out:json][timeout:60];(way["highway"](around:' + str(int(_radius_meters)) + ',' + str(_center_lat) + ',' + str(_center_lon) + '););out body;>;out skel qt;'
	var url: String = "https://overpass-api.de/api/interpreter?data=" + query.uri_encode()
	var headers: PackedStringArray = PackedStringArray(["User-Agent: GodotMapFetcher/1.0"])
	var err: int = _http_overpass.request(url, headers)
	if err != OK:
		map_error.emit("Failed to send Overpass request")
		_dlog("ERROR: Overpass request failed")


func _on_overpass_response(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_roads_time = Time.get_ticks_msec()

	if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
		map_error.emit("Overpass query failed (HTTP " + str(response_code) + ").")
		_dlog("ERROR: Overpass failed HTTP " + str(response_code))
		return

	var json: Variant = JSON.parse_string(body.get_string_from_utf8())
	if json == null:
		map_error.emit("Invalid Overpass response.")
		_dlog("ERROR: Invalid Overpass JSON")
		return
	var data: Dictionary = json as Dictionary
	if not data.has("elements"):
		map_error.emit("Invalid Overpass response.")
		_dlog("ERROR: No elements in Overpass response")
		return

	var nodes_by_id: Dictionary = {}
	var ways: Array = []
	var elements: Array = data["elements"] as Array

	for elem: Variant in elements:
		var e: Dictionary = elem as Dictionary
		var etype: String = str(e["type"])
		if etype == "node":
			nodes_by_id[int(e["id"])] = {
				"lat": float(e["lat"]),
				"lon": float(e["lon"])
			}
		elif etype == "way":
			ways.append(e)

	_total_nodes = nodes_by_id.size()
	_total_ways = ways.size()
	_dlog("Overpass returned " + str(_total_nodes) + " nodes, " + str(_total_ways) + " ways")

	var type_counts: Dictionary = {}
	_road_data.clear()
	for way: Variant in ways:
		var w: Dictionary = way as Dictionary
		var road_name: String = ""
		if w.has("tags"):
			var tags: Dictionary = w["tags"] as Dictionary
			if tags.has("name"):
				road_name = str(tags["name"])

		var road_type: String = "unknown"
		if w.has("tags"):
			var tags: Dictionary = w["tags"] as Dictionary
			if tags.has("highway"):
				road_type = str(tags["highway"])

		if type_counts.has(road_type):
			type_counts[road_type] = int(type_counts[road_type]) + 1
		else:
			type_counts[road_type] = 1

		var points: Array = []
		var node_ids: Array = w["nodes"] as Array
		for nid: Variant in node_ids:
			var nid_int: int = int(nid)
			if nodes_by_id.has(nid_int):
				var node_data: Dictionary = nodes_by_id[nid_int] as Dictionary
				var local_pos: Vector2 = _latlon_to_local(float(node_data["lat"]), float(node_data["lon"]))
				points.append(local_pos)

		if points.size() >= 2:
			_road_data.append({
				"name": road_name,
				"type": road_type,
				"points": points
			})

	for t: Variant in type_counts:
		_dlog("  " + str(t) + ": " + str(type_counts[t]))

	_dlog("Parsed " + str(_road_data.size()) + " valid roads")
	_build_road_lines()
	_fetch_tiles()


func _fetch_tiles() -> void:
	var lat_offset: float = _radius_meters / 111320.0
	var lon_offset: float = _radius_meters / (111320.0 * cos(deg_to_rad(_center_lat)))

	var min_lat: float = _center_lat - lat_offset
	var max_lat: float = _center_lat + lat_offset
	var min_lon: float = _center_lon - lon_offset
	var max_lon: float = _center_lon + lon_offset

	var tile_min: Vector2i = _latlon_to_tile(max_lat, min_lon, tile_zoom)
	var tile_max: Vector2i = _latlon_to_tile(min_lat, max_lon, tile_zoom)

	_tile_bounds = {
		"min_x": tile_min.x,
		"max_x": tile_max.x,
		"min_y": tile_min.y,
		"max_y": tile_max.y
	}

	_tile_queue.clear()
	for tx: int in range(tile_min.x, tile_max.x + 1):
		for ty: int in range(tile_min.y, tile_max.y + 1):
			_tile_queue.append({"x": tx, "y": ty, "z": tile_zoom})

	_tiles_total = _tile_queue.size()
	_dlog("Fetching " + str(_tiles_total) + " tiles (zoom " + str(tile_zoom) + ")...")

	if _tiles_total > 200:
		_dlog("WARNING: Large tile count, consider lower zoom")

	_fetch_next_tile()


func _fetch_next_tile() -> void:
	if _tile_queue.is_empty():
		_stitch_tiles()
		return

	var t: Dictionary = _tile_queue.pop_front() as Dictionary
	var url: String = "https://tile.openstreetmap.org/" + str(int(t["z"])) + "/" + str(int(t["x"])) + "/" + str(int(t["y"])) + ".png"
	var headers: PackedStringArray = PackedStringArray(["User-Agent: GodotMapFetcher/1.0"])

	_http_tiles.set_meta("current_tile", t)
	var err: int = _http_tiles.request(url, headers)
	if err != OK:
		_tiles_failed += 1
		_fetch_next_tile()


func _on_tile_response(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var t: Dictionary = _http_tiles.get_meta("current_tile", {}) as Dictionary

	if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
		var img: Image = Image.new()
		var err: int = img.load_png_from_buffer(body)
		if err == OK:
			var key: String = str(int(t["x"])) + "_" + str(int(t["y"]))
			_tile_images[key] = img
			_tiles_loaded += 1
		else:
			_tiles_failed += 1
	else:
		_tiles_failed += 1

	if (_tiles_loaded + _tiles_failed) % 10 == 0:
		_dlog("Tiles: " + str(_tiles_loaded) + "/" + str(_tiles_total) + " loaded, " + str(_tiles_failed) + " failed")

	await get_tree().create_timer(0.1).timeout
	_fetch_next_tile()


func _build_road_lines() -> void:
	_roads_node = Node2D.new()
	_roads_node.name = "Roads"
	add_child(_roads_node)
	if Engine.is_editor_hint():
		_roads_node.owner = get_tree().edited_scene_root

	var width_map: Dictionary = {
		"motorway": 6.0,
		"trunk": 5.0,
		"primary": 4.0,
		"secondary": 3.5,
		"tertiary": 3.0,
		"residential": 2.0,
		"service": 1.5,
		"footway": 1.0,
		"cycleway": 1.0,
		"path": 0.8,
	}

	var color_map: Dictionary = {
		"motorway": Color(0.9, 0.6, 0.2),
		"trunk": Color(0.9, 0.7, 0.3),
		"primary": Color(0.9, 0.8, 0.4),
		"secondary": Color(0.95, 0.9, 0.5),
		"tertiary": Color(1.0, 1.0, 1.0),
		"residential": Color(0.8, 0.8, 0.8),
		"service": Color(0.6, 0.6, 0.6),
		"footway": Color(0.6, 0.4, 0.3),
		"cycleway": Color(0.3, 0.5, 0.8),
		"path": Color(0.5, 0.4, 0.3),
	}

	for road: Variant in _road_data:
		var r: Dictionary = road as Dictionary
		var road_name: String = str(r["name"])
		var road_type: String = str(r["type"])
		var points: Array = r["points"] as Array

		var line: Line2D = Line2D.new()
		if road_name != "":
			line.name = road_name
		else:
			line.name = "Road_" + str(_roads_node.get_child_count())
		line.set_meta("road_type", road_type)
		line.set_meta("road_name", road_name)

		var w: float = 2.0
		if width_map.has(road_type):
			w = float(width_map[road_type])
		line.width = w
		line.set_meta("road_width", w)

		var c: Color = Color(0.7, 0.7, 0.7)
		if color_map.has(road_type):
			c = color_map[road_type] as Color
		line.default_color = c
		line.joint_mode = Line2D.LINE_JOINT_ROUND
		line.begin_cap_mode = Line2D.LINE_CAP_ROUND
		line.end_cap_mode = Line2D.LINE_CAP_ROUND
		line.antialiased = true

		for pt: Variant in points:
			var p: Vector2 = pt as Vector2
			line.add_point(p * pixels_per_meter)

		_roads_node.add_child(line)
		if Engine.is_editor_hint():
			line.owner = get_tree().edited_scene_root

	_dlog("Built " + str(_roads_node.get_child_count()) + " road Line2D nodes")


func _stitch_tiles() -> void:
	_tiles_time = Time.get_ticks_msec()
	_dlog("Tiles done: " + str(_tiles_loaded) + " loaded, " + str(_tiles_failed) + " failed")

	if _tile_images.is_empty():
		_dlog("WARNING: No tiles loaded")
		_finalize()
		return

	var min_x: int = int(_tile_bounds["min_x"])
	var max_x: int = int(_tile_bounds["max_x"])
	var min_y: int = int(_tile_bounds["min_y"])
	var max_y: int = int(_tile_bounds["max_y"])

	var cols: int = max_x - min_x + 1
	var rows: int = max_y - min_y + 1
	var tile_px: int = 256

	var stitched: Image = Image.create(cols * tile_px, rows * tile_px, false, Image.FORMAT_RGB8)

	for tx: int in range(min_x, max_x + 1):
		for ty: int in range(min_y, max_y + 1):
			var key: String = str(tx) + "_" + str(ty)
			if _tile_images.has(key):
				var src_img: Image = _tile_images[key] as Image
				src_img.convert(Image.FORMAT_RGB8)
				var dest_x: int = (tx - min_x) * tile_px
				var dest_y: int = (ty - min_y) * tile_px
				stitched.blit_rect(src_img, Rect2i(0, 0, tile_px, tile_px), Vector2i(dest_x, dest_y))

	var nw_latlon: Vector2 = _tile_to_latlon(min_x, min_y, tile_zoom)
	var se_latlon: Vector2 = _tile_to_latlon(max_x + 1, max_y + 1, tile_zoom)

	var ground_width: float = _haversine_distance(nw_latlon.x, nw_latlon.y, nw_latlon.x, se_latlon.y)
	var ground_height: float = _haversine_distance(nw_latlon.x, nw_latlon.y, se_latlon.x, nw_latlon.y)

	_dlog("Ground size: " + str(int(ground_width)) + "m x " + str(int(ground_height)) + "m")
	_dlog("Stitched image: " + str(stitched.get_width()) + "x" + str(stitched.get_height()) + " px")

	var tex: ImageTexture = ImageTexture.create_from_image(stitched)

	_ground_node = Node2D.new()
	_ground_node.name = "GroundTiles"
	_ground_node.z_index = -1
	add_child(_ground_node)
	if Engine.is_editor_hint():
		_ground_node.owner = get_tree().edited_scene_root

	var sprite: Sprite2D = Sprite2D.new()
	sprite.texture = tex
	sprite.centered = true

	var target_w: float = ground_width * pixels_per_meter
	var target_h: float = ground_height * pixels_per_meter
	sprite.scale = Vector2(target_w / float(stitched.get_width()), target_h / float(stitched.get_height()))

	var center_frac_x: float = _lon_to_tile_x(_center_lon, tile_zoom)
	var center_frac_y: float = _lat_to_tile_y(_center_lat, tile_zoom)
	var grid_center_x: float = float(min_x + max_x + 1) / 2.0
	var grid_center_y: float = float(min_y + max_y + 1) / 2.0
	var offset_frac_x: float = center_frac_x - grid_center_x
	var offset_frac_y: float = center_frac_y - grid_center_y
	var tile_w: float = ground_width / float(cols)
	var tile_h: float = ground_height / float(rows)
	sprite.position = Vector2(
		-offset_frac_x * tile_w * pixels_per_meter,
		-offset_frac_y * tile_h * pixels_per_meter
	)

	_ground_node.add_child(sprite)
	if Engine.is_editor_hint():
		sprite.owner = get_tree().edited_scene_root

	stitched.save_png("user://map_tiles_stitched.png")
	_dlog("Saved stitched image to user://map_tiles_stitched.png")
	_finalize()


func _finalize() -> void:
	var total_time: int = Time.get_ticks_msec() - _fetch_start_time
	_dlog("=== COMPLETE ===")
	_dlog("Total time: " + str(total_time) + "ms")
	_dlog("Roads: " + str(_road_data.size()) + " | Nodes: " + str(_total_nodes) + " | Ways: " + str(_total_ways))
	_dlog("Tiles: " + str(_tiles_loaded) + "/" + str(_tiles_total) + " loaded")

	if debug_enabled:
		_build_debug_overlay()

	map_ready.emit()


func _build_debug_overlay() -> void:
	if _debug_node:
		_debug_node.queue_free()

	_debug_node = Node2D.new()
	_debug_node.name = "DebugOverlay"
	_debug_node.z_index = 100
	add_child(_debug_node)
	if Engine.is_editor_hint():
		_debug_node.owner = get_tree().edited_scene_root

	var debug_draw: Node2D = _DebugDrawScene.instantiate()
	debug_draw.set("fetcher_path", get_path())
	_debug_node.add_child(debug_draw)
	if Engine.is_editor_hint():
		debug_draw.owner = get_tree().edited_scene_root


func _latlon_to_local(lat: float, lon: float) -> Vector2:
	var dlat: float = lat - _center_lat
	var dlon: float = lon - _center_lon
	var x: float = dlon * 111320.0 * cos(deg_to_rad(_center_lat))
	var y: float = -dlat * 110540.0
	return Vector2(x, y)


func _latlon_to_tile(lat: float, lon: float, zoom: int) -> Vector2i:
	var n: float = pow(2.0, zoom)
	var x: int = int(floor((lon + 180.0) / 360.0 * n))
	var lat_rad: float = deg_to_rad(lat)
	var y: int = int(floor((1.0 - log(tan(lat_rad) + 1.0 / cos(lat_rad)) / PI) / 2.0 * n))
	return Vector2i(x, y)


func _lon_to_tile_x(lon: float, zoom: int) -> float:
	var n: float = pow(2.0, zoom)
	return (lon + 180.0) / 360.0 * n


func _lat_to_tile_y(lat: float, zoom: int) -> float:
	var n: float = pow(2.0, zoom)
	var lat_rad: float = deg_to_rad(lat)
	return (1.0 - log(tan(lat_rad) + 1.0 / cos(lat_rad)) / PI) / 2.0 * n


func _tile_to_latlon(tx: int, ty: int, zoom: int) -> Vector2:
	var n: float = pow(2.0, zoom)
	var lon: float = float(tx) / n * 360.0 - 180.0
	var lat_rad: float = atan(sinh(PI * (1.0 - 2.0 * float(ty) / n)))
	var lat: float = rad_to_deg(lat_rad)
	return Vector2(lat, lon)


func _haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
	var R: float = 6371000.0
	var dlat: float = deg_to_rad(lat2 - lat1)
	var dlon: float = deg_to_rad(lon2 - lon1)
	var a: float = sin(dlat / 2.0) * sin(dlat / 2.0) + \
		cos(deg_to_rad(lat1)) * cos(deg_to_rad(lat2)) * \
		sin(dlon / 2.0) * sin(dlon / 2.0)
	var c: float = 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
	return R * c


var _DebugDrawScene: PackedScene = null

func _init() -> void:
	_DebugDrawScene = _make_debug_draw_scene()

func _make_debug_draw_scene() -> PackedScene:
	var node: Node2D = Node2D.new()
	node.set_script(_get_debug_script())
	var scene: PackedScene = PackedScene.new()
	scene.pack(node)
	node.queue_free()
	return scene

func _get_debug_script() -> GDScript:
	var s: GDScript = GDScript.new()
	s.source_code = """extends Node2D

@export var fetcher_path: NodePath = ^""

func _process(_delta: float) -> void:
	queue_redraw()

func _draw() -> void:
	var fetcher: Node = get_node_or_null(fetcher_path)
	if fetcher == null:
		return
	if not bool(fetcher.get("debug_enabled")):
		return

	var ppm: float = float(fetcher.get("pixels_per_meter"))
	var radius_m: float = float(fetcher.get("_radius_meters"))
	var radius_px: float = radius_m * ppm
	var font_size: int = int(fetcher.get("debug_font_size"))
	var log_arr: Array = fetcher.get("debug_log") as Array

	draw_arc(Vector2.ZERO, radius_px, 0.0, TAU, 64, Color(1, 0, 0, 0.3), 2.0, true)
	draw_line(Vector2(-10, 0), Vector2(10, 0), Color.RED, 2.0)
	draw_line(Vector2(0, -10), Vector2(0, 10), Color.GREEN, 2.0)
	draw_circle(Vector2.ZERO, 4.0, Color(1, 1, 0, 0.8))

	var panel_pos: Vector2 = Vector2(20, 20)
	var line_height: int = font_size + 4
	var max_lines: int = 30
	var start_idx: int = max(0, log_arr.size() - max_lines)
	var visible_count: int = min(log_arr.size(), max_lines)

	var bg_height: int = (visible_count + 2) * line_height + 10
	draw_rect(Rect2(panel_pos - Vector2(5, 5), Vector2(500, bg_height)), Color(0, 0, 0, 0.7))

	var addr_str: String = str(fetcher.get("address"))
	var clat: float = float(fetcher.get("_center_lat"))
	var clon: float = float(fetcher.get("_center_lon"))
	var header: String = "MapFetcher Debug | " + addr_str + " | " + str(clat) + ", " + str(clon)
	draw_string(ThemeDB.fallback_font, panel_pos, header, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.YELLOW)

	var y_pos: float = panel_pos.y + float(line_height)
	for i: int in range(start_idx, log_arr.size()):
		var entry: String = str(log_arr[i])
		var color: Color = Color.WHITE
		if entry.find("ERROR") != -1:
			color = Color.RED
		elif entry.find("WARNING") != -1:
			color = Color.ORANGE
		elif entry.find("===") != -1:
			color = Color.GREEN
		draw_string(ThemeDB.fallback_font, Vector2(panel_pos.x, y_pos), entry, HORIZONTAL_ALIGNMENT_LEFT, 490, font_size, color)
		y_pos += float(line_height)
"""
	s.reload()
	return s
